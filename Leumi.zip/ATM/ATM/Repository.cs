﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ATM
{
    class Repository
    {
        public Dictionary<string, CardType> LoadCardTypes()
        {
            Dictionary<string, CardType>
            cardTypes = JsonConvert.DeserializeObject<Dictionary<string, CardType>>(File.ReadAllText(@"cardtypes.json"));
            return cardTypes;
        }

        public List<CustomerCard> LoadCustomerCards()
        {
            List<CustomerCard> customerCards = JsonConvert.DeserializeObject<List<CustomerCard>>(File.ReadAllText(@"customercards.json"));
            return customerCards;
        }

        public CustomerAccount LoadATMMashine( )
        {
            CustomerAccount atmmashine = JsonConvert.DeserializeObject<CustomerAccount>(File.ReadAllText(@"atmmashine.json"));
            return atmmashine;
        }

        public void SaveCustomerCards(List<CustomerCard> customerCards)
        {
            File.WriteAllText(@"customercards.json", JsonConvert.SerializeObject(customerCards));
        }

        public void SaveATMMashine(CustomerAccount atmmashine)
        {
            File.WriteAllText(@"atmmashine.json", JsonConvert.SerializeObject(atmmashine));
        }

        public CustomerAccount CreateATMMashine()
        {
            CustomerAccount
            atmmashine = new CustomerAccount
            {
                Customer = new Customer
                {
                    Name = "ATM TA",
                    Telephone = "7712121212"
                },
                Branch = new Branch
                {
                    Name = "TA",
                    Id = "111",
                    Bank = new Bank
                    {
                        Id = "10",
                        Name = "Leumi"
                    }
                },
                Account = new Account
                {
                    Balance = 100000,
                    Id = "10101010"

                }
            };
            return atmmashine;
         //   File.WriteAllText(@"atmmashine.json", JsonConvert.SerializeObject(atmmashine));
        }

        public List<CustomerCard> CreateCustomerCards()
        {
            List<CustomerCard> customerCards = new List<CustomerCard>();
            CustomerCard cc = new CustomerCard
            {
                CustomerAccount = new CustomerAccount
                {
                    Customer = new Customer
                    {
                        Name = "Tal D.",
                        Telephone = "771111111"
                    },
                    Branch = new Branch
                    {
                        Name = "TA",
                        Id = "111",
                        Bank = new Bank
                        {
                            Id = "10",
                            Name = "Leumi"
                        }
                    },
                    Account = new Account
                    {
                        Balance = 30000,
                        Id = "111111"

                    }
                },
                Card = new Card
                {
                    Name ="Visa",
                    Pin = "1111",
                    Pan = "1111111111",
                    ExpireDate = (DateTime.Now).AddYears(5)
                }
            };
            customerCards.Add(cc);

            CustomerCard cc1 = new CustomerCard
            {
                CustomerAccount = new CustomerAccount
                {
                    Customer = new Customer
                    {
                        Name = "Nir T.",
                        Telephone = "772222222"
                    },
                    Branch = new Branch
                    {
                        Name = "PT",
                        Id = "222",
                        Bank = new Bank
                        {
                            Id = "12",
                            Name = "Apoalim"
                        }
                    },
                    Account = new Account
                    {
                        Balance = 40000,
                        Id = "222222222"

                    }
                },
                Card = new Card
                {
                    Name = "American Express",
                    Pin = "2222",
                    Pan = "22222222222",
                    ExpireDate = (DateTime.Now).AddYears(5)
                }
            };
            customerCards.Add(cc1);
            CustomerCard cc2 = new CustomerCard
            {
                CustomerAccount = new CustomerAccount
                {
                    Customer = new Customer
                    {
                        Name = "Lena S.",
                        Telephone = "77-33333333"
                    },
                    Branch = new Branch
                    {
                        Name = "SU",
                        Id = "333",
                        Bank = new Bank
                        {
                            Id = "16",
                            Name = "Mosad"
                        }
                    },
                    Account = new Account
                    {
                        Balance = 50000,
                        Id = "33333333"

                    }
                },
                Card = new Card
                {
                    Name = "Mastercard",
                    Pin = "3333",
                    Pan = "33333333333",
                    ExpireDate = (DateTime.Now).AddYears(5)
                }
            };
            customerCards.Add(cc2);
            return customerCards;
        //    File.WriteAllText(@"customercards.json", JsonConvert.SerializeObject(customerCards));
        }

        public void CreateCardTypes(Dictionary<string, CardType> CardTypes)
        {
            CardType cardtype = new CardType
            {
                Name = "Visa",
                MaxWithdraw = 1000,
                Fees = new Fees { FeeForTranfer = 5 },
                Benefits = new Benefits { PointsForTranfer = 4 }
            };
            CardTypes.Add(cardtype.Name, cardtype);
            CardType cardtype1 = new CardType();
            cardtype1.Name = "Mastercard";
            cardtype1.MaxWithdraw = 900;
            cardtype1.Fees = new Fees();
            cardtype1.Fees.FeeForTranfer = 4;
            cardtype1.Benefits = new Benefits { PointsForTranfer = 3 };
            CardTypes.Add(cardtype1.Name, cardtype1);
            CardType cardtype3 = new CardType();
            cardtype3.Name = "American Express";
            cardtype3.MaxWithdraw = 800;
            cardtype3.Fees = new Fees { FeeForTranfer = 3 };
            cardtype3.Benefits = new Benefits { PointsForTranfer = 2 };
            CardTypes.Add(cardtype3.Name, cardtype3);
            File.WriteAllText(@"cardtypes.json", JsonConvert.SerializeObject(CardTypes));
        }
    }
}
