﻿using ATM.BL;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using System.Xml;
using log4net;
using log4net.Config;
using System.Reflection;
using System.IO;

namespace ATM
{
    class Program
    {
        [DllImport("Kernel32")]
        private static extern bool SetConsoleCtrlHandler(EventHandler handler, bool add);

        private delegate bool EventHandler(CtrlType sig);
        static EventHandler _handler;

        enum CtrlType
        {
            CTRL_C_EVENT = 0,
            CTRL_BREAK_EVENT = 1,
            CTRL_CLOSE_EVENT = 2,
            CTRL_LOGOFF_EVENT = 5,
            CTRL_SHUTDOWN_EVENT = 6
        }

        private static bool Handler(CtrlType sig)
        {
            switch (sig)
            {
                case CtrlType.CTRL_C_EVENT:
                    atm.Dispose();
                    //Environment.Exit(-1);
                    return true;
                case CtrlType.CTRL_LOGOFF_EVENT:
                    atm.Dispose();
                   // Environment.Exit(-1);
                    return true;
                case CtrlType.CTRL_SHUTDOWN_EVENT:
                    atm.Dispose();
                  //  Environment.Exit(-1);
                    return true;
                case CtrlType.CTRL_CLOSE_EVENT:
                    atm.Dispose();
                   // Environment.Exit(-1);
                    return true;
                default:
                    return false;

            }
        }

        private static ATM_Simple atm;
        static void Main(string[] args)
        {
 
            _handler += new EventHandler(Handler);
            SetConsoleCtrlHandler(_handler, true);
            Console.WriteLine("Hello World!");
            atm = new ATM_Simple();
          //  string str;
            UI ui = new UI(atm);
            do
            {
               // ui.Login();
            }
            while (true);


        }



    }
 
}
