﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;
using log4net;
using log4net.Config;
using Newtonsoft.Json;

namespace ATM.BL
{
    class ATM_Simple : IDisposable
    {
        private CustomerAccount atmMashine { get; set; }
        private Dictionary<string, CardType> cardTypes { get; set; }
        private List<CustomerCard> customerCards { get; set; }
        private Repository repository { get; set; }
        private CustomerCard currentCard { get; set; } = null;

        public void Dispose() 
        {
            repository.SaveCustomerCards(customerCards);
            repository.SaveATMMashine(atmMashine);
        }

        public string WithdrawProblem { get; set; }
        private string useFreshData { get; set; }
        private int limitPerDay { get; set; }
        private ILog logger { get; set; }

        public ATM_Simple()
        {
            XmlDocument log4netConfig = new XmlDocument();
            log4netConfig.Load(File.OpenRead("log4net.config"));
            var repo = LogManager.CreateRepository(Assembly.GetEntryAssembly(), typeof(log4net.Repository.Hierarchy.Hierarchy));
            XmlConfigurator.Configure(repo, log4netConfig["log4net"]);

            logger = LogManager.GetLogger(typeof(ATM_Simple));

            
            useFreshData = ConfigurationManager.AppSettings.Get("UseFreshData");
            limitPerDay = Int32.Parse(ConfigurationManager.AppSettings.Get("WithdrawsLimitPerDay"));
            initData();
        }

        private void initData() 
        {
            logger.Info("Start initData(). useFreshData is "+ useFreshData);
            repository = new Repository();
            if (useFreshData == "true")
            {
                customerCards=repository.CreateCustomerCards();
                atmMashine=repository.CreateATMMashine();
            }
            else
            {
                customerCards=repository.LoadCustomerCards();
                atmMashine=repository.LoadATMMashine();
            }
            cardTypes=repository.LoadCardTypes();
        }

        public List<Transfer> GetWithdrawList(int v)
        {
            logger.Info("Start GetWithdrawList(). count is " + v.ToString());
            return currentCard.CustomerAccount.Withdraws.OrderByDescending(x => x.Date).Take(v).ToList();
        }

        private bool checkLimitsPerDay()
        {
            var baselineDate = DateTime.Now.AddHours(-24);
            int count = currentCard.CustomerAccount.Withdraws.Where(p => p.Date >= baselineDate).Count();
            logger.Info("checkLimitsPerDay(). count is " + count.ToString());
            return count < limitPerDay ? true : false;
        }

        public bool FindCard(string pin)
        {
            logger.Info("Start FindCard(). pin is " + pin);
            currentCard = customerCards.FirstOrDefault(s => s.Card.Pin == pin);
            return currentCard != null ? true : false;            
        }

        internal void EditPin(string str)
        {
            logger.Info("Start EditPin. New pin is " + str +". Old pin is "+ currentCard.Card.Pin);
            currentCard.Card.Pin = str;
        }

        public string GetCurrentBalsnce()
        {
            logger.Info("GetCurrentBalsnce(). CurrentBalsnce is " + currentCard.CustomerAccount.Account.Balance.ToString());
            return currentCard.CustomerAccount.Account.Balance.ToString();
        }

        internal void EditMobile(string str)
        {
            logger.Info("Start EditMobile. New mobile is " + str + ". Old mobile is " + currentCard.CustomerAccount.Customer.Mabile);
            currentCard.CustomerAccount.Customer.Mabile = str;
        }

        public  string GetCardTypeLimit()
        {
            logger.Info("GetCardTypeLimit(). CardTypeLimit is " + cardTypes[currentCard.Card.Name].MaxWithdraw.ToString());
            return cardTypes[currentCard.Card.Name].MaxWithdraw.ToString();
        }

        public bool Tranfer(double amount)
        {
            logger.Info("Start Tranfer. amount is " + amount.ToString());
            WithdrawProblem = "";
            bool ret = true;
            double fee = cardTypes[currentCard.Card.Name].Fees.FeeForTranfer;
            if (checkLimitsPerDay())
            {
                if (amount <= cardTypes[currentCard.Card.Name].MaxWithdraw)
                {
                    if (currentCard.CustomerAccount.Account.CheckBalance(amount + fee))
                    {
                        if (atmMashine.Account.CheckBalance(amount))
                        {
                            currentCard.CustomerAccount.Account.Balance -= amount + fee;
                            currentCard.Card.BenefitPoints += cardTypes[currentCard.Card.Name].Benefits.PointsForTranfer;
                            atmMashine.Account.Balance -= amount;
                            currentCard.CustomerAccount.Withdraws.Add(new Transfer
                            {
                                Account = atmMashine.Branch.Bank.Id + "-" + atmMashine.Branch.Id + "-" + atmMashine.Account.Id,
                                Amount = amount,
                                Date = DateTime.Now,
                                Fee = fee
                            });
                            atmMashine.Withdraws.Add(new Transfer
                            {
                                Account = currentCard.CustomerAccount.Branch.Bank.Id + "-" + currentCard.CustomerAccount.Branch.Id + "-" + currentCard.CustomerAccount.Account.Id,
                                Amount = amount,
                                Date = DateTime.Now,
                                Fee = fee
                            });
                            logger.Info("Tranfer complete. From account " + currentCard.CustomerAccount.Branch.Bank.Id + "-" + currentCard.CustomerAccount.Branch.Id + "-" + currentCard.CustomerAccount.Account.Id +
                                " To account " + atmMashine.Branch.Bank.Id + "-" + atmMashine.Branch.Id + "-" + atmMashine.Account.Id);
                        }
                        else 
                        {
                            WithdrawProblem = "Cash balance in ATM less than request amount.";
                            ret = false; 
                        }
                    }
                    else
                    {
                        WithdrawProblem = "Account balance less than request amount.";
                        ret = false;
                    }
                }
                else 
                {
                    WithdrawProblem = "Card type limit less than request amount.";
                    ret = false; 
                }
            }
            else
            {
                WithdrawProblem = "Total withdraws are limited to 10 per day.";
                ret = false;
            }
            if (!ret) logger.Info("Tranfer problem. " + WithdrawProblem);

            return ret;
        }

        public string GetATMName()
        {
            return atmMashine.Customer.Name;
        }
    }


}
