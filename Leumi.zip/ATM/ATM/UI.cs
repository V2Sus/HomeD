﻿using ATM.BL;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ATM
{
    class UI
    {
        public UI(ATM_Simple _atm)
        {
            atm_name = _atm.GetATMName();
            atm = _atm;
            login();
        }

        private ATM_Simple atm { get; set; }
        private string atm_name { get; set; }
        private void header()
        {
            Console.Clear();
            Console.WriteLine("\b"+atm_name);

            Console.WriteLine("=======================================================================================");
        }

        public void login()
        {
            header();
            Console.WriteLine("PINs available for demo: 1111,2222,3333");
            Console.WriteLine("Enter PIN:");
           
            if (atm.FindCard(inputNumber())) mainMenu();
            else
            {
                login();
            }
        }

        public void mainMenu()
        {
            header();
            Console.WriteLine("Select action:");
            Console.WriteLine("0. Exit");
            Console.WriteLine("1. Cash withdraw");
            Console.WriteLine("2. Five previous cash withdrawals");
            Console.WriteLine("3. Edit PIN");
            Console.WriteLine("4. Edit Mobile");
            string sel=inputNumber();
            switch (sel)
            {
                case ("0"): login(); break;
                case ("1"): withdraw(); break;
                case ("2"): withdrawsList(); break;
                case ("3"): editPin(); break;
                case ("4"): editMobile(); break;
            }
            mainMenu();
        }

        private void withdrawsList()
        {
            List<Transfer> list= atm.GetWithdrawList(5);
            header();
            Console.WriteLine("\tAccountNo\t\tAmount\t\tDate\t\t\t\tFee");
            foreach (Transfer li in list)
            {
                Console.WriteLine("\t" +li.Account+"\t\t"+li.Amount+"\t\t"+li.Date+"\t\t"+li.Fee);
            }
            toMainMenu();
        }

        private void toMainMenu()
        {
            Console.WriteLine("\n\n\n\nPress any key to continue...");
            Console.ReadKey();
            mainMenu();
        }

        private void editPin()
        {
            header();
            Console.WriteLine("Enter new PIN:");
            string str = inputNumber();
            atm.EditPin(str);
            Console.WriteLine("\nSuccessfully changed!!!");
            toMainMenu();
        }

        private void editMobile()
        {
            header();
            Console.WriteLine("Enter new mobile number:");
            string str = inputNumber();
            atm.EditMobile(str);
            Console.WriteLine("\nSuccessfully changed!!!");
            toMainMenu();
        }

        private void withdraw()
        {
            header();
            Console.WriteLine("Account balance: "+ atm.GetCurrentBalsnce());
            Console.WriteLine("Card type withdraw limit: " + atm.GetCardTypeLimit());
            Console.WriteLine("Enter Amount:");
            string amountstr = inputNumber();
            double amount=0;
            double.TryParse(amountstr, out amount);
            if (atm.Tranfer(amount))
            {
                Console.WriteLine("\nSuccessful withdraw money!!!");
                toMainMenu();
            }
            else
            {
                Console.WriteLine("\nWithdraw money problem.");
                Console.WriteLine(atm.WithdrawProblem);
                toMainMenu();
            }
        }

        public string inputNumber()
        {
            string _val = "";
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);
                if (key.Key != ConsoleKey.Backspace)
                {
                    double val = 0;
                    bool _x = double.TryParse(key.KeyChar.ToString(), out val);
                    if (_x)
                    {
                        _val += key.KeyChar;
                        Console.Write(key.KeyChar);
                    }
                }
                else
                {
                    if (key.Key == ConsoleKey.Backspace && _val.Length > 0)
                    {
                        _val = _val.Substring(0, (_val.Length - 1));
                        Console.Write("\b \b");
                    }
                }
            }
            // Stops Receving Keys Once Enter is Pressed
            while (key.Key != ConsoleKey.Enter);
            return _val;
        }

    }
}
