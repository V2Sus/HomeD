﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class Transfer
    {
        public string Account { get; set; }
        public double Amount { get; set; }
        public DateTime Date { get; set; }

        public double Fee { get; set; }
    }
}
