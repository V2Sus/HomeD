﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class CardType
    {
        public Benefits Benefits { get; set; }
        public Fees Fees { get; set; }
        public string Name { get; set; }
        public double MaxWithdraw { get; set; }
    }
}
