﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class CustomerAccount
    {
        public CustomerAccount()
        {
            Withdraws = new List<Transfer>();
        }
        public Branch Branch { get; set; }
        public Customer Customer { get; set; }
        public Account Account { get; set; }

        public List<Transfer> Withdraws { get; set; }
    }
}
