﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class Benefits
    {
        public uint PointsForTranfer;
    }
}
