﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class Fees
    {
        public double FeeForTranfer;
    }
}
