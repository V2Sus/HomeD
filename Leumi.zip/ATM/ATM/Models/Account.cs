﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class Account
    {
        public string Id { get; set; }
        public double Balance{get; set;}

        public bool CheckBalance(double amount)
        {
            return amount <= Balance ? true : false;
        }

    }
}
