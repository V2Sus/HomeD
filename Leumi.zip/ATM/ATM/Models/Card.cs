﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class Card
    {
        public string Name { get; set; }
        public string Pan { get; set; }
        public string Pin { get; set; }
        public ushort Cvc { get; set; }
        public DateTime ExpireDate { get; set; }
        public uint BenefitPoints { get; set; } = 0;

        public double FeeForTranfer { get; set; } = 0;

    }
}
