﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class CustomerCard 
    {
        public CustomerAccount CustomerAccount { get; set; }
        public Card Card { get; set; }

    }
}
